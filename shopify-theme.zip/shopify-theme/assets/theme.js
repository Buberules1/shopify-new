
(function() {
  // Mobile menu toggle
  document.addEventListener('DOMContentLoaded', function() {
    const toggleButtons = document.querySelectorAll('.js-toggle-mobile-menu');
    const mobileMenu = document.querySelector('.js-mobile-menu');
    
    if (toggleButtons.length && mobileMenu) {
      toggleButtons.forEach(button => {
        button.addEventListener('click', function() {
          mobileMenu.classList.toggle('hidden');
          document.body.classList.toggle('overflow-hidden');
        });
      });
    }
    
    // Product image gallery
    const thumbnails = document.querySelectorAll('.product-thumbnail');
    const mainImage = document.querySelector('.product-main-image');
    
    if (thumbnails.length && mainImage) {
      thumbnails.forEach(thumb => {
        thumb.addEventListener('click', function() {
          // Remove active class from all thumbnails
          thumbnails.forEach(t => t.classList.remove('ring-2', 'ring-primary'));
          
          // Add active class to clicked thumbnail
          this.classList.add('ring-2', 'ring-primary');
          
          // Update main image
          const imgSrc = this.querySelector('img').getAttribute('src').replace('small', 'large');
          const imgAlt = this.querySelector('img').getAttribute('alt');
          
          mainImage.querySelector('img').setAttribute('src', imgSrc);
          mainImage.querySelector('img').setAttribute('alt', imgAlt);
        });
      });
    }
    
    // Theme toggler (simplified version since we can't fully implement without more complex features)
    const themeToggle = document.querySelector('.js-theme-toggle');
    
    if (themeToggle) {
      themeToggle.addEventListener('click', function() {
        const html = document.documentElement;
        
        if (html.classList.contains('dark')) {
          html.classList.remove('dark');
          html.classList.add('night-light');
          localStorage.setItem('theme', 'night-light');
        } else if (html.classList.contains('night-light')) {
          html.classList.remove('night-light');
          localStorage.setItem('theme', 'light');
        } else {
          html.classList.add('dark');
          localStorage.setItem('theme', 'dark');
        }
      });
    }
    
    // Initialize theme from localStorage
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
      document.documentElement.classList.remove('light', 'dark', 'night-light');
      document.documentElement.classList.add(savedTheme);
    }
    
    // Add to cart animation
    const addToCartButtons = document.querySelectorAll('.js-product-form button[type="submit"]');
    
    if (addToCartButtons.length) {
      addToCartButtons.forEach(button => {
        button.addEventListener('click', function(e) {
          e.preventDefault();
          
          const form = this.closest('form');
          const formData = new FormData(form);
          
          // AJAX add to cart (in a real implementation, this would use fetch to submit to Shopify)
          fetch('/cart/add.js', {
            method: 'POST',
            body: formData
          })
          .then(response => response.json())
          .then(data => {
            // Show success message
            const originalText = this.innerHTML;
            this.innerHTML = 'Added to Cart!';
            
            setTimeout(() => {
              this.innerHTML = originalText;
            }, 2000);
            
            // In a real implementation, we would update the cart count here
          })
          .catch(error => {
            console.error('Error:', error);
          });
        });
      });
    }
  });
})();
