
# GlowVolt Shopify Theme

This theme is designed for the GlowVolt Shopify store, featuring a clean, modern design with warm color palette and glass-like UI elements.

## Download Instructions

To download this theme:

1. Click the green "Code" button at the top of this GitHub repository
2. Select "Download ZIP"
3. Extract the ZIP file to your computer

## Installation Instructions

1. Go to your Shopify admin dashboard
2. Navigate to Online Store > Themes
3. Click "Add theme" and select "Upload ZIP file"
4. Select the ZIP file you downloaded (no need to re-zip)
5. After upload completes, click "Customize" to begin configuring your theme

## Troubleshooting

If the theme doesn't look as expected after upload:

1. Make sure all section files (in sections folder) are properly uploaded
2. Check that the theme.css file is in the assets folder
3. Verify that all Liquid templates are properly formatted with no syntax errors
4. Customize the theme settings in Shopify's theme editor

## Theme Features

- Responsive design for all screen sizes
- Glass-morphism UI elements with subtle blur effects
- Product showcase sections with floating animations
- Testimonial displays with star ratings
- Feature highlights with gradient backgrounds
- Custom collection grid layout

## Customization

The theme can be customized through the Shopify theme editor. Major sections include:
- Header navigation with logo and cart
- Hero section with animated product image
- Collection grid for showcasing product categories
- Product highlight section with call-to-action
- Features section to showcase product benefits
- Testimonials section with customer reviews
- Footer with navigation and social links

## Theme Structure

```
shopify-theme/
├── assets/
│   ├── theme.css       # Main stylesheet
│   └── theme.js        # Theme JavaScript
├── config/
│   └── settings_schema.json  # Theme settings
├── layout/
│   └── theme.liquid    # Main layout template
├── sections/          
│   ├── header.liquid   # Site header
│   ├── footer.liquid   # Site footer
│   ├── hero.liquid     # Hero banner
│   ├── collection-grid.liquid  # Collection display
│   ├── product-highlight.liquid  # Featured product
│   ├── features.liquid  # Product features
│   └── testimonials.liquid  # Customer reviews
├── snippets/
│   └── product-card.liquid  # Product display card
└── templates/
    ├── index.liquid    # Homepage template
    ├── product.liquid  # Product page template
    └── collection.liquid  # Collection page template
```

## Support

For support with this theme, please open an issue in this repository or contact the theme creator.
